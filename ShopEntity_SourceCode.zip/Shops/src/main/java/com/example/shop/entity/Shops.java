package com.example.shop.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class Shops {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	
	private Long Id;
	private String Name;
	public Long getId() {
		return Id;
	}
	public void setId(Long id) {
		Id = id;
	}
	public   String getName() {
		return Name;
	}
	public void setName(String name) {
		Name = name;
	}
	public Shops() {
	}
	public Shops(Long id, String name) {
		super();
		Id = id;
		Name = name;
	}
	@Override
	public String toString() {
		return "Shops [Id=" + Id + ", Name=" + Name + "]";
	}
	
}
